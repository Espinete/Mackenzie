import base64
import xbmcgui
import xbmc
from bs4 import BeautifulSoup
import requests
import re

def pcloud(page_data, url):
    xbmcgui.Dialog().textviewer("estoy dentro de mi funcion", url)
    response = requests.get(url)
    html_content = response.text
    soup = BeautifulSoup(html_content, 'html.parser')
    element_v1 = soup.find(text=re.compile(r"(?s)\"path\": \"\\([^"]+).*"))
    if element_v1:
        match_v1 = re.search(r"(?s)\"path\": \"\\([^"]+).*", element_var1)
        if match_v1:
            v1 = match_v1.group(1)
            #xbmcgui.Dialog().textviewer("retorno esto...", v1)
            return v1