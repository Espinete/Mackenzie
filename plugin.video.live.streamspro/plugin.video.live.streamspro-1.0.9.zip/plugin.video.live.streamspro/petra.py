import base64
import xbmcgui
import xbmc
import xbmcplugin
import xbmcaddon
from bs4 import BeautifulSoup
import requests
import re
import sys

def cajon(page_data, url):
    
        dialog = xbmcgui.Dialog()
        respuesta = dialog.select('¿ Qué eliges ver ?', ['                                <<<  [COLOR green][B]Ver pelicula[/B][/COLOR]  >>>', '                                    <<  [COLOR green][B]Ver trailer[/B][/COLOR]  >>'])
        if respuesta == -1:
            #xbmcgui.Dialog().textviewer("estoy click en cancelar", str(respuesta))
            xbmc.executebuiltin("Action(Back)")
            
            return
            
        if respuesta == 0: 
            if url.startswith('plugin://plugin.video.palantir3'):
                addon_id = 'plugin.video.palantir3'               
                addon = xbmcaddon.Addon(addon_id)    
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, xbmcgui.ListItem(path=url))
                
            else:
                #xbmcgui.Dialog().textviewer("cuando no es pal", url)
                return url
        elif respuesta == 1:
            
                if page_data.startswith('plugin://plugin.video.imdb.trailers'):
                    addon_id = 'plugin.video.imdb.trailers'
                    addon = xbmcaddon.Addon(addon_id)
                    list_item = xbmcgui.ListItem(path=page_data)
                    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=list_item)
                    
                else:
                    #xbmcgui.Dialog().textviewer("estoy dentro de youtube", page_data)
                    addon_id = 'plugin.video.duffyou'
                    addon = xbmcaddon.Addon(addon_id)
                    list_item = xbmcgui.ListItem(path=page_data)
                    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=list_item)