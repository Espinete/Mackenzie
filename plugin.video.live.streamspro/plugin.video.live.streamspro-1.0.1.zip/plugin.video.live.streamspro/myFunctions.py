import base64
import xbmcgui
import xbmc
from bs4 import BeautifulSoup
import requests
import re

def encode(page_data, a):
    c = base64.b64encode(a.encode('utf-8'))
    return c
    
def addme(page_data, a, b):
    return a + b  
    
def m3u(page_data, url):
    #xbmcgui.Dialog().textviewer("estoy dentro de getSoup", url)
   
    response = requests.get(url)
    html_content = response.text
    # Supongamos que tienes el contenido HTML almacenado en la variable 'data'
    soup = BeautifulSoup(html_content, 'html.parser')
    # Encuentra el elemento que contiene el texto "setVideoHLS('"
    element = soup.find(text=re.compile(r"setVideoHLS\('(.+?)'\)"))
    if element:
        match = re.search(r"setVideoHLS\('(.+?)'\)", element)
        if match:
            url_final = match.group(1)
            #xbmcgui.Dialog().ok("Estoy dentro de getSoup", url_final)            
            #xbmc.log("URL final encontrada: {}".format(url_final))
            return url_final
            

        
    
