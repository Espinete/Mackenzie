import base64
import xbmcgui
import xbmc
from bs4 import BeautifulSoup
import requests
import re

def encode(page_data, a):
    c = base64.b64encode(a.encode('utf-8'))
    return c
    
def addme(page_data, a, b):
    return a + b  
    
def m3u(page_data, url):
    #xbmcgui.Dialog().textviewer("estoy dentro de mi funcion", url)   
    response = requests.get(url)
    html_content = response.text    
    soup = BeautifulSoup(html_content, 'html.parser')
 
    element = soup.find(text=re.compile(r"setVideoHLS\('(.+?)'\)"))
    if element:
        match = re.search(r"setVideoHLS\('(.+?)'\)", element)
        if match:
            url_final = match.group(1)
            #xbmcgui.Dialog().ok("Estoy dentro de getSoup", url_final)            
            #xbmc.log("URL final encontrada: {}".format(url_final))
            return url_final

def pcloud(page_data, url):
    #xbmcgui.Dialog().textviewer("estoy dentro de mi funcion", url)   
    response = requests.get(url)
    html_content = response.text    
    soup = BeautifulSoup(html_content, 'html.parser')
 
    element_v1 = soup.find(text=re.compile(r'(?s)"path": "\\([^"]+).*'))
    element_v2 = soup.find(text=re.compile(r'(?s)\"hosts\": \[.*?\"([^"]+).*'))
    
    if element_v1:
        match = re.search(r'(?s)"path": "\\([^"]+).*', element_v1)
        if match:
            v1 = match.group(1)
            #xbmcgui.Dialog().textviewer("resultado variable 1", v1)            
    if element_v2:
        match = re.search(r'(?s)\"hosts\": \[.*?\"([^"]+).*', element_v2)
        if match:
            v2 = match.group(1)
            #xbmcgui.Dialog().textviewer("resultado variable 2", v2)
            
    url_final = f"https://{v2}{v1}"
    #xbmcgui.Dialog().textviewer("resultado variable 2", url_final)
    return url_final 

def Fullpcloud(page_data, url):
    #xbmcgui.Dialog().textviewer("estoy dentro de mi funcion", url)   
    response = requests.get(url)
    html_content = response.text    
    soup = BeautifulSoup(html_content, 'html.parser')
 
    element = soup.find(text=re.compile(r'(?s)\"downloadlink\": \"https:\\/\\/([^"]+)'))
    #xbmcgui.Dialog().textviewer("estoy dentro de mi funcion", element)
    if element:
        match = re.search(r'(?s)\"downloadlink\": \"https:\\/\\/([^"]+)', element)
        if match:
            v1 = match.group(1)
            url_final = f"https://{v1}"
            #xbmcgui.Dialog().textviewer("estoy dentro de mi funcion", url_final)
            return url_final    