import requests
import re
import xbmcvfs
import xbmc
import xbmcgui
import sys
import html

def tex_url(url):
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
    response = requests.get(url, headers=headers)
    response.raise_for_status()  # Lanza una excepción para errores HTTP
    response.encoding = 'utf-8'
    html_content = response.text
    return html_content
def tele():
    regex_1, regex_2, regex_3, regex_4, regex_5, regex_6, regex_7 = ""
    #hora_inicio_la1 = programa_la1 = hora_fin_la1 = programa2_la1 = info_1 = "No disponible"
    TRANSLATEPATH = xbmcvfs.translatePath
    url_local = 'special://home/addons/plugin.video.play/Tvdirec.html'
    direccion = TRANSLATEPATH(url_local)    
    
    url_regex = 'https://dl.dropbox.com/scl/fi/91vp54hg1hv0wxnf81dqm/regex-de-television.html?rlkey=wl8ikk3284dzplocd13hfetpf&st=7w2260nk&dl=0'
    html_content = tex_url(url_regex)
    variables = r"regex='(.*?)'"
    b_urls = r"url='(.*?)'"
    match_variables = re.findall(variables, html_content, re.DOTALL)
    regex_1, regex_2, regex_3, regex_4, regex_5, regex_6, regex_7 = match_variables
    urls = re.findall(b_urls, html_content, re.DOTALL)
    
###################################################################################################3    
    url_la1 = f"{urls[1]}"    
    html_content = tex_url(url_la1)     
    patron = rf'{regex_1}'    
    matches = re.findall(patron, html_content, re.DOTALL)        
    
    if matches:
        hora_inicio_la1 = matches[0][0]  # Captura la hora
        programa_la1 = matches[0][1]  # Captura el contenido después del <span>
        hora_fin_la1 = matches[0][2]  # Captura la siguiente hora
        programa2_la1 = matches[0][3]       
        strong_matches = re.findall(rf'{regex_2}', programa_la1)       
        num_matches = len(strong_matches)
        
        if num_matches >=2:
            info = re.findall(rf'{regex_3}', programa_la1)
            info = info[0]
            info = info.replace('</p><p>', ' /// ')
            info_1 = "[COLOR gold]Ahora Peli:[/COLOR] D" + info
            programa_la1 = strong_matches[1]            
        else:
            info = re.findall(rf'{regex_4}', programa_la1)
            info_1 = info[0] if info else ""
            if info_1 == "":
                info = re.findall(rf'{regex_7}', programa_la1)
                info_1 = info[0] if info else ""
            programa_la1 = strong_matches[0] if strong_matches else ""            
        strong_matches = re.findall(rf'{regex_5}', programa2_la1)
        num_matches = len(strong_matches)
        if num_matches >=2:
            programa2_la1 = strong_matches[1]
        else:
            programa2_la1 = strong_matches[0] if strong_matches else ""              
    else:
        patron = rf'{regex_6}'    
        matches = re.findall(patron, html_content, re.DOTALL)
        hora_inicio_la1 = matches[0][0]
        programa_la1 = matches[0][1]
        hora_fin_la1 = '[COLOR red]cierre[/COLOR]'
        info_1 = matches[0][2]
        programa2_la1 = 'Chapo'
##################################################################################################        
    url_la2 = f"{urls[2]}"    
    html_content = tex_url(url_la2)     
    patron = rf'{regex_1}'    
    matches = re.findall(patron, html_content, re.DOTALL)
    ###tupla = matches[0]###num_elementos = len(tupla)###xbmc.log(f"URL FINAL ES :   + {matches}", xbmc.LOGINFO)
    ###xbmcgui.Dialog().ok("a ver", f"Captura {num_elementos}")###sys.exit()
    if matches:
        hora_inicio_la2 = matches[0][0]  # Captura la hora
        programa_la2 = matches[0][1]  # Captura el contenido después del <span>
        hora_fin_la2 = matches[0][2]  # Captura la siguiente hora
        programa2_la2 = matches[0][3]
        
        strong_matches = re.findall(rf'{regex_2}', programa_la2)       
        num_matches = len(strong_matches)        
        if num_matches >=2:
            info = re.findall(rf'{regex_3}', programa_la2)
            info = info[0]
            info = info.replace('</p><p>', ' /// ')
            info_2 = "[COLOR gold]Ahora Peli:[/COLOR] D" + info
            programa_la2 = strong_matches[1]            
        else:           
            info = re.findall(rf'{regex_4}', programa_la2)
            info_2 = info[0] if info else ""
            if info_2 == "":
                info = re.findall(rf'{regex_7}', programa_la2)
                info_2 = info[0] if info else ""
            programa_la2 = strong_matches[0] if strong_matches else "" 
            
        strong_matches = re.findall(rf'{regex_5}', programa2_la2)
        num_matches = len(strong_matches)
        if num_matches >=2:
            programa2_la2 = strong_matches[1]
        else:
            programa2_la2 = strong_matches[0] if strong_matches else ""     # Grupo 4
    else:
        patron = rf'{regex_6}'    
        matches = re.findall(patron, html_content, re.DOTALL)
        hora_inicio_la2 = matches[0][0]
        programa_la2 = matches[0][1]
        hora_fin_la2 = '[COLOR red]cierre[/COLOR]'
        info_2 = matches[0][2]
        programa2_la2 = 'Chapo'
##########################################################################################        
    url_a3 = f"{urls[3]}"
    html_content = tex_url(url_a3)   
    patron = rf'{regex_1}'    
    matches = re.findall(patron, html_content, re.DOTALL)
    
    if matches:
        hora_inicio_a3 = matches[0][0]  # Captura la hora
        programa_a3 = matches[0][1]  # Captura el contenido después del <span>
        hora_fin_a3 = matches[0][2]  # Captura la siguiente hora
        programa2_a3 = matches[0][3]       
        strong_matches = re.findall(rf'{regex_2}', programa_a3)       
        num_matches = len(strong_matches)
        if num_matches >=2:
            info = re.findall(rf'{regex_3}', programa_a3)
            info = info[0]
            info = info.replace('</p><p>', ' /// ')
            info_3 = "[COLOR gold]Ahora Peli:[/COLOR] D" + info
            programa_a3 = strong_matches[1]            
        else:
            
            info = re.findall(rf'{regex_4}', programa_a3)
            info_3 = info[0] if info else ""
            if info_3 == "":
                info = re.findall(rf'{regex_7}', programa_a3)
                info_3 = info[0] if info else ""
            programa_a3 = strong_matches[0] if strong_matches else ""            
        strong_matches = re.findall(rf'{regex_5}', programa2_a3)
        num_matches = len(strong_matches)
        if num_matches >=2:
            programa2_a3 = strong_matches[1]
        else:
            programa2_a3 = strong_matches[0] if strong_matches else ""
    else:
        patron = rf'{regex_6}'   
        matches = re.findall(patron, html_content, re.DOTALL)
        hora_inicio_a3 = matches[0][0]
        programa_a3 = matches[0][1]
        hora_fin_a3 = '[COLOR red]cierre[/COLOR]'
        info_3 = matches[0][2]
        programa2_a3 = 'Chapo'  
#########################################################################################################        
    url_4 = f"{urls[4]}"    
    html_content = tex_url(url_4)  
    patron = rf'{regex_1}'    
    matches = re.findall(patron, html_content, re.DOTALL)
    if matches:
        hora_inicio_4 = matches[0][0]  # Captura la hora
        programa_4 = matches[0][1]  # Captura el contenido después del <span>
        hora_fin_4 = matches[0][2]  # Captura la siguiente hora
        programa2_4 = matches[0][3]       
        strong_matches = re.findall(rf'{regex_2}', programa_4)       
        num_matches = len(strong_matches)
        if num_matches >=2:
            info = re.findall(rf'{regex_3}', programa_4)
            info = info[0]
            info = info.replace('</p><p>', ' /// ')
            info_4 = "[COLOR gold]Ahora Peli:[/COLOR] D" + info
            programa_4 = strong_matches[1]            
        else:
            
            info = re.findall(rf'{regex_4}', programa_4)
            info_4 = info[0] if info else ""
            if info_4 == "":
                info = re.findall(rf'{regex_7}', programa_4)
                info_4 = info[0] if info else ""
            programa_4 = strong_matches[0] if strong_matches else ""            
        strong_matches = re.findall(rf'{regex_5}', programa2_4)
        num_matches = len(strong_matches)
        if num_matches >=2:
            programa2_4 = strong_matches[1]
        else:
            programa2_4 = strong_matches[0] if strong_matches else ""
    else:
        patron = rf'{regex_6}'   
        matches = re.findall(patron, html_content, re.DOTALL)
        hora_inicio_4 = matches[0][0]
        programa_4 = matches[0][1]
        hora_fin_4 = '[COLOR red]cierre[/COLOR]'
        info_4 = matches[0][2]
        programa2_4 = 'Chapo'
############################################################################################################        
    url_5 = f"{urls[5]}"    
    html_content = tex_url(url_5)  
    patron = rf'{regex_1}'    
    matches = re.findall(patron, html_content, re.DOTALL)
    if matches:
        hora_inicio_5 = matches[0][0]  # Captura la hora
        programa_5 = matches[0][1]  # Captura el contenido después del <span>
        hora_fin_5 = matches[0][2]  # Captura la siguiente hora
        programa2_5 = matches[0][3]       
        strong_matches = re.findall(rf'{regex_2}', programa_5)       
        num_matches = len(strong_matches)
        if num_matches >=2:
            info = re.findall(rf'{regex_3}', programa_5)
            info = info[0]
            info = info.replace('</p><p>', ' /// ')
            info_5 = "[COLOR gold]Ahora Peli:[/COLOR] D" + info
            programa_5 = strong_matches[1]            
        else:
            
            info = re.findall(rf'{regex_4}', programa_5)
            info_5 = info[0] if info else ""
            if info_5 == "":
                info = re.findall(rf'{regex_7}', programa_5)
                info_5 = info[0] if info else ""
            programa_5 = strong_matches[0] if strong_matches else ""            
        strong_matches = re.findall(rf'{regex_5}', programa2_5)
        num_matches = len(strong_matches)
        if num_matches >=2:
            programa2_5 = strong_matches[1]
        else:
            programa2_5 = strong_matches[0] if strong_matches else "" 
    else:
        patron = rf'{regex_6}'   
        matches = re.findall(patron, html_content, re.DOTALL)
        hora_inicio_5 = matches[0][0]
        programa_5 = matches[0][1]
        hora_fin_5 = '[COLOR red]cierre[/COLOR]'
        info_5 = matches[0][2]
        programa2_5 = 'Chapo'
###########################################################################################################
    url_6 = f"{urls[6]}"    
    html_content = tex_url(url_6)  
    patron = rf'{regex_1}'    
    matches = re.findall(patron, html_content, re.DOTALL)
    #if not matches:
        #info_6 =  "Fin de emision"
        #programa_6 = hora_fin_6 = programa2_6 = hora_inicio_6 = ""
    if matches:
        hora_inicio_6 = matches[0][0]  # Captura la hora
        programa_6 = matches[0][1]  # Captura el contenido después del <span>
        hora_fin_6 = matches[0][2]  # Captura la siguiente hora
        programa2_6 = matches[0][3]       
        strong_matches = re.findall(rf'{regex_2}', programa_6)       
        num_matches = len(strong_matches)
        if num_matches >=2:
            info = re.findall(rf'{regex_3}', programa_6)
            info = info[0]
            info = info.replace('</p><p>', ' /// ')
            info_6 = "[COLOR gold]Ahora Peli:[/COLOR] D" + info
            programa_6 = strong_matches[1]            
        else:
            
            info = re.findall(rf'{regex_4}', programa_6)
            info_6 = info[0] if info else ""
            if info_6 == "":
                info = re.findall(rf'{regex_7}', programa_6)
                info_6 = info[0] if info else ""
            programa_6 = strong_matches[0] if strong_matches else ""            
        strong_matches = re.findall(rf'{regex_5}', programa2_6)
        num_matches = len(strong_matches)
        if num_matches >=2:
            programa2_6 = strong_matches[1]
        else:
            programa2_6 = strong_matches[0] if strong_matches else ""
    else:
        patron = rf'{regex_6}'     
        matches = re.findall(patron, html_content, re.DOTALL)
        hora_inicio_6 = matches[0][0]
        programa_6 = matches[0][1]
        hora_fin_6 = '[COLOR red]cierre[/COLOR]'
        info_6 = matches[0][2]
        programa2_6 = 'Chapo'
######################################################################################################        
    url_mega = f"{urls[7]}"    
    html_content = tex_url(url_mega)  
    patron = rf'{regex_1}'    
    matches = re.findall(patron, html_content, re.DOTALL)
    if matches:
        hora_inicio_mega = matches[0][0]  # Captura la hora
        programa_mega = matches[0][1]  # Captura el contenido después del <span>
        hora_fin_mega = matches[0][2]  # Captura la siguiente hora
        programa2_mega = matches[0][3]       
        strong_matches = re.findall(rf'{regex_2}', programa_mega)       
        num_matches = len(strong_matches)
        if num_matches >=2:
            info = re.findall(rf'{regex_3}', programa_mega)
            info = info[0]
            info = info.replace('</p><p>', ' /// ')
            info_mega = "[COLOR gold]Ahora Peli:[/COLOR] D" + info
            programa_mega = strong_matches[1]            
        else:
            
            info = re.findall(rf'{regex_4}', programa_mega)
            info_mega = info[0] if info else ""
            if info_mega == "":
                info = re.findall(rf'{regex_7}', programa_mega)
                info_mega = info[0] if info else ""
            programa_mega = strong_matches[0] if strong_matches else ""            
        strong_matches = re.findall(rf'{regex_5}', programa2_mega)
        num_matches = len(strong_matches)
        if num_matches >=2:
            programa2_mega = strong_matches[1]
        else:
            programa2_mega = strong_matches[0] if strong_matches else "" 
    else:
        patron = rf'{regex_6}'     
        matches = re.findall(patron, html_content, re.DOTALL)
        hora_inicio_mega = matches[0][0]
        programa_mega = matches[0][1]
        hora_fin_mega = '[COLOR red]cierre[/COLOR]'
        info_mega = matches[0][2]
        programa2_mega = 'Chapo'
###############################################################################################        
    items_contenido = f"""
    <item>
|User-Agent=iPad
<title>[COLOR red][B]&lt;&lt;&lt;[/B][/COLOR] Real Madrid [COLOR red][B]&gt;&gt;&gt;[/B][/COLOR]</title>

<inputstream>{urls[8]}</inputstream>

<thumbnail>https://dl.dropbox.com/scl/fi/jel04pm0h4ic10osd6oed/png-transparent-real-madrid-logo-real-madrid-c-f-la-liga-uefa-champions-league-hala-madrid-real-madrid-miscellaneous-emblem-madrid-thumbnail-removebg-preview.png?rlkey=rj8dsukvcl46ktug06zeuons5&st=oojl0peg&dl=0</thumbnail> 
<fanart>https://dl.dropbox.com/scl/fi/y142bticyu7qkhjbn7nuz/logo-de-real-madrid-en-bandera-de-espana_1920x1080_xtrafondos.com.jpg?rlkey=a5567jhrlfzearzpxspbnx2ny&dl=0</fanart> 
</item>
<item>
|User-Agent=iPad
<title>[COLOR red][B]&lt;&lt;&lt;[/B][/COLOR] Vamos por M+ [COLOR red][B]&gt;&gt;&gt;[/B][/COLOR]</title>

<inputstream>{urls[9]}</inputstream>

<thumbnail>https://boxtvmania.wordpress.com/wp-content/uploads/2018/08/vamos_b.png</thumbnail> 
<fanart>https://www.movistarplus.es/recorte/n/detallegaleriah/F3829338</fanart> 
</item>
<item>
|User-Agent=iPad
<title>[COLOR red][B]&lt;&lt;&lt;[/B][/COLOR] Originales por M+ [COLOR red][B]&gt;&gt;&gt;[/B][/COLOR]</title>

<inputstream>{urls[10]}</inputstream>

<thumbnail>https://upload.wikimedia.org/wikipedia/commons/d/d9/Movistar%2B_Logo.png</thumbnail> 
<fanart>https://www.mundoplus.tv/wp-content/uploads/2023/07/noticiaoriginalesmp.jpg</fanart> 
</item>	
<item>
|User-Agent=iPad
<title>[COLOR red][B]&lt;&lt;&lt;[/B][/COLOR] Liga de campeones [COLOR red][B]&gt;&gt;&gt;[/B][/COLOR]</title>

<inputstream>{urls[11]}</inputstream>

<thumbnail>https://meritocraciablanca.com/wp-content/uploads/movistar-liga-de-campeones.jpg</thumbnail> 
<fanart>https://cdnuploads.aa.com.tr/uploads/Contents/2020/03/13/thumbs_b_c_d4dea6c8f73e2c20748724a91df9eda8.jpg?v=155557</fanart> 
</item>
<item>
|User-Agent=iPad
<title>[COLOR red][B]&lt;&lt;&lt;[/B][/COLOR] La liga por M+ [COLOR red][B]&gt;&gt;&gt;[/B][/COLOR]</title>

<inputstream>{urls[12]}</inputstream>

<thumbnail>https://nowsat.info/wp-content/uploads/Movistar-La-Liga.png</thumbnail> 
<fanart>https://www.adslzone.net/app/uploads-adslzone.net/2019/06/movistar-laliga.jpg</fanart> 
</item>
<item>
|User-Agent=iPad
<title>[COLOR red][B]&lt;&lt;&lt;[/B][/COLOR] La liga por DAZN [COLOR red][B]&gt;&gt;&gt;[/B][/COLOR]</title>

<inputstream>{urls[13]}</inputstream>

<thumbnail>https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQy_ksQdMUyVhmYlbc0jPEMkIR6lQcfi-6YdA&s</thumbnail> 
<fanart>https://image.discovery.indazn.com/ca/v2/ca/image?id=jejfa7zjwwah17fk7z2md5t6e_image-header_pEs_1723118324000&quality=70</fanart> 
</item>
<item>
|User-Agent=iPad
<title>[COLOR red][B]&lt;&lt;&lt;[/B][/COLOR] DAZN F1 [COLOR red][B]&gt;&gt;&gt;[/B][/COLOR]</title>
<link>$doregex[series]</link>
	<regex>
		<name>series</name>
		<expres>$pyFunction:petra.Tv("{urls[14]}")</expres>
		<page></page>
	</regex>


<thumbnail>https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS-PunDrOk63t5jeOvoEuZp6JlKyF9MZ4FYk9KdgHXs84fREfY1g-SLJq7bcLkZmfarfaw&usqp=CAU</thumbnail> 
<fanart>https://image.discovery.indazn.com/ca/v2/ca/image?id=y44drrjcqtxa18g3arxjz58ge_image-header_pEs_1723117975000&quality=70</fanart> 
</item>
<item>
|User-Agent=iPad
<title>De [B][COLOR green]{hora_inicio_la1}[/COLOR][/B] a [B][COLOR green]{hora_fin_la1}[/B][/COLOR][COLOR violet] {programa_la1}[/COLOR] y después [COLOR violet]{programa2_la1}[/COLOR]</title>
<link>$doregex[series]</link>
	<regex>
		<name>series</name>         
		<expres>$pyFunction:petra.Tv("{urls[15]}")</expres>
		<page></page>
	</regex>
<thumbnail>https://tvguia.info/wp-content/uploads/2021/11/La-1-TVE1.png</thumbnail> 
<fanart>https://css2.rtve.es/css/rtve.guiatv/tv1/tv1.jpg</fanart> 
<info>{info_1}</info>
</item>
<item>

<title>De [B][COLOR green]{hora_inicio_la2}[/COLOR][/B] a [B][COLOR green]{hora_fin_la2}[/B][/COLOR][COLOR violet] {programa_la2}[/COLOR] y después [COLOR violet]{programa2_la2}[/COLOR]</title>

	<inputstream>{urls[16]}</inputstream>
<thumbnail>https://upload.wikimedia.org/wikipedia/commons/thumb/6/63/La_2_HD.png/220px-La_2_HD.png</thumbnail> 
<fanart>https://css2.rtve.es/css/rtve.guiatv/la2/la2.jpg</fanart> 
<info>{info_2}</info>
</item>

<item>
<title>De [B][COLOR green]{hora_inicio_a3}[/COLOR][/B] a [B][COLOR green]{hora_fin_a3}[/B][/COLOR][COLOR violet] {programa_a3}[/COLOR] y después [COLOR violet]{programa2_a3}[/COLOR]</title>

	<inputstream>{urls[17]}</inputstream>

<thumbnail>https://dl.dropbox.com/scl/fi/2bo3vb4qt7c7imhthxq0u/logo-antena-3-removebg-preview.png?rlkey=yb0y6j2rph97bewi82xarp209&st=ithybpwl&dl=0</thumbnail> 
<fanart>https://fotografias.antena3.com/clipping/cmsimages02/2025/01/27/62AFA8B2-2481-4117-9FE5-F5041DBD43A4/antena3-logo-principal_96.jpg?crop=2720,1530,x0,y0&width=1200&height=675&optimize=low&format=jpg</fanart>
<info>{info_3}</info> 
</item>
<item>
<title>De [B][COLOR green]{hora_inicio_4}[/COLOR][/B] a [B][COLOR green]{hora_fin_4}[/B][/COLOR][COLOR violet] {programa_4}[/COLOR] y después [COLOR violet]{programa2_4}[/COLOR]</title>
	<inputstream>{urls[18]}</inputstream>

<thumbnail>https://upload.wikimedia.org/wikipedia/commons/b/b2/Cuatro_HD2012.png</thumbnail> 
<fanart>https://album.mediaset.es/eimg/2019/12/11/5z1nOkrDX2JPsYHlBFv8Q.jpg</fanart> 
<info>{info_4}</info> 
</item>
<item>
<title>De [B][COLOR green]{hora_inicio_5}[/COLOR][/B] a [B][COLOR green]{hora_fin_5}[/B][/COLOR][COLOR violet] {programa_5}[/COLOR] y después [COLOR violet]{programa2_5}[/COLOR]</title>
	<inputstream>{urls[19]}</inputstream>

<thumbnail>https://static.wikia.nocookie.net/josemota/images/2/2f/Telecinco_esfera.png/revision/latest?cb=20150907010629&path-prefix=es</thumbnail> 
<fanart>https://fotografias.larazon.es/clipping/cmsimages02/2024/08/30/3DD0E2BA-4BE0-4612-A053-1C37DE834C09/telecinco-revoluciona-imagen-cortinillas-slow-motion-modo-noche-innovador_98.jpg?crop=1024,576,x0,y0&width=1900&height=1069&optimize=low&format=webply</fanart> 
<info>{info_5}</info>
</item>
<item>
<title>De [B][COLOR green]{hora_inicio_6}[/COLOR][/B] a [B][COLOR green]{hora_fin_6}[/B][/COLOR][COLOR violet] {programa_6}[/COLOR] y después [COLOR violet]{programa2_6}[/COLOR]</title>
	<inputstream>{urls[20]}</inputstream>

<thumbnail>https://play-lh.googleusercontent.com/ovbyfLUWwVuYQKJ2icuywmkuUKJw50oGQugM5go8d7k_7Hu14-MElvhedcNSLmI0FA</thumbnail> 
<fanart>https://graffica.ams3.digitaloceanspaces.com/2024/05/58.webp</fanart> 
<info>{info_6}</info>
</item>
<item>
<title>De [B][COLOR green]{hora_inicio_mega}[/COLOR][/B] a [B][COLOR green]{hora_fin_mega}[/B][/COLOR][COLOR violet] {programa_mega}[/COLOR] y después [COLOR violet]{programa2_mega}[/COLOR]</title>
	<link>$doregex[series]</link>

	<regex>
		<name>series</name>
		<expres>$pyFunction:petra.Tv("{urls[21]}")</expres>
		<page></page>
	</regex>


<thumbnail>https://play-lh.googleusercontent.com/DpTYi3WkwJIWNfPZIBonDsYJGL8f6Pp4yKbET7k7_XVvNMWkwNKXmRYiKCpQzSyPdYQ</thumbnail> 
<fanart>https://pbs.twimg.com/media/GkTEbl5WgAA1z5c.jpg</fanart> 
<info>{info_mega}</info>
</item>
"""    
    
    try:
        # Leer el contenido actual del archivo
        with open(direccion, 'r', encoding='utf-8') as archivo:
            contenido_actual = archivo.read()
    except FileNotFoundError:
        #xbmcgui.Dialog().ok("Error de Archivo", "No se encontró el archivo en la ruta especificada.")
        return
    except IOError as e:
        #xbmcgui.Dialog().ok("Error de Archivo", f"No se pudo leer el archivo: {e}")
        return

    pos_inicio_items = contenido_actual.find("<items>")
    pos_fin_items = contenido_actual.find("</items>")
    
    if pos_inicio_items != -1 and pos_fin_items != -1:
        # Crear el nuevo contenido reemplazando lo que está entre <items> y </items>
        contenido_modificado = (contenido_actual[:pos_inicio_items + len("<items>")] + 
                                "\n" + items_contenido + "\n" + 
                                contenido_actual[pos_fin_items:])
        
        try:
            # Escribir el contenido modificado de vuelta al archivo
            with open(direccion, 'w', encoding='utf-8') as archivo:
                archivo.write(contenido_modificado)
            #xbmcgui.Dialog().ok("Éxito", "El archivo se actualizó correctamente.")
        except IOError as e:
            #xbmcgui.Dialog().ok("Error de Archivo", f"No se pudo escribir en el archivo: {e}")
            return
    else:
        xbmc.log("Error", xbmc.LOGINFO)
        xbmcgui.Dialog().ok("Error de XML", "No se encontró la etiqueta <items> en el archivo.") 
        return

    #xbmcgui.Dialog().ok("Proceso Completado", f"El archivo ha sido actualizado: {direccion}")
    
    return direccion