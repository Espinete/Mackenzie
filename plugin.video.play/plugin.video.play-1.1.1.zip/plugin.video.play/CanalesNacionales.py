import requests
import re
import xbmcvfs
import xbmc
import xbmcgui
import sys
import html
from concurrent.futures import ThreadPoolExecutor, as_completed
def tex_url(url):
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
    response = requests.get(url, headers=headers)
    response.raise_for_status()  # Lanza una excepción para errores HTTP
    response.encoding = 'utf-8'
    return response.text

    
def procesar_url(url):
    """Función para extraer y procesar información desde la URL dada."""
    html_content = tex_url(url)
    matches = re.findall(rf'{regex_1}', html_content, re.DOTALL)

    if matches:
        hora_inicio, programa, hora_fin, programa2 = matches[0][0], matches[0][1], matches[0][2], matches[0][3]

        strong_matches = re.findall(rf'{regex_2}', programa)
        if len(strong_matches) >= 2:
            info = re.findall(rf'{regex_3}', programa)
            info_color = "[COLOR gold]Ahora Peli:[/COLOR] D" + info[0].replace('</p><p>', ' /// ') if info else ""
            programa = strong_matches[1]
        else:
            info = re.findall(rf'{regex_4}', programa)
            info_color = info[0] if info else ""
            if not info_color:
                info = re.findall(rf'{regex_5}', programa)
                info_color = info[0] if info else ""
            programa = strong_matches[0] if strong_matches else ""

        strong_matches = re.findall(rf'{regex_2}', programa2)
        programa2 = strong_matches[1] if len(strong_matches) >= 2 else (strong_matches[0] if strong_matches else "")

    else:
        matches = re.findall(rf'{regex_6}', html_content, re.DOTALL)
        hora_inicio, programa, info_color = matches[0][0], matches[0][1], matches[0][2]
        hora_fin, programa2 = '[COLOR red]cierre[/COLOR]', 'Chapo'

    return hora_inicio, programa, hora_fin, info_color, programa2
    
def tele():
    global regex_1, regex_2, regex_3, regex_4, regex_5, regex_6 
    TRANSLATEPATH = xbmcvfs.translatePath
    url_local = 'special://home/addons/plugin.video.play/Tvdirec.html'
    direccion = TRANSLATEPATH(url_local)    
    url_regex = 'https://dl.dropbox.com/scl/fi/1anpnc1rtogjjquv8qj3s/regex-canlaes-nacionales.html?rlkey=cnt8ktumx416qug8a6rbv2k7h&st=6bfmp87n&dl=0'
    html_content = tex_url(url_regex)
    variables = r"regex='(.*?)'"
    b_urls = r"url='(.*?)'"
    match_variables = re.findall(variables, html_content, re.DOTALL)
    regex_1, regex_2, regex_3, regex_4, regex_5, regex_6 = match_variables
    urls = re.findall(b_urls, html_content, re.DOTALL)    
    
    results = {}

    # Usamos ThreadPoolExecutor para hacer las llamadas concurrentes
    with ThreadPoolExecutor(max_workers=5) as executor:
        future_to_url = {executor.submit(procesar_url, urls[i]): i for i in range(1, len(urls), 2)}

        for future in as_completed(future_to_url):
            url_index = future_to_url[future]  # Obtener el índice original de la URL
            try:
                results[url_index] = future.result()  # Guardar el resultado con su índice
            except Exception as exc:
                xbmcgui.Dialog().ok("Error al guardar", f"Error en la URL {urls[url_index]}: {exc}")

    # Ordenar los resultados según el índice original de las URLs
    ordered_results = [results[i] for i in sorted(results.keys())]

    # Asignar los resultados a variables específicas
    if len(ordered_results) >= 1:  # Asegurar que haya suficientes resultados
        (hora_inicio_la1, programa_la1, hora_fin_la1, info_1, programa2_la1), \
        (hora_inicio_la2, programa_la2, hora_fin_la2, info_2, programa2_la2), \
        (hora_inicio_a3, programa_a3, hora_fin_a3, info_3, programa2_a3), \
        (hora_inicio_4, programa_4, hora_fin_4, info_4, programa2_4), \
        (hora_inicio_5, programa_5, hora_fin_5, info_5, programa2_5), \
        (hora_inicio_6, programa_6, hora_fin_6, info_6, programa2_6), \
        (hora_inicio_mega, programa_mega, hora_fin_mega, info_mega, programa2_mega), \
        (hora_inicio_Paramount, programa_Paramount, hora_fin_Paramount, info_Paramount, programa2_Paramount), \
        (hora_inicio_fdf, programa_fdf, hora_fin_fdf, info_fdf, programa2_fdf) = ordered_results

    
    #1_Capturamos todo el contenido en texto
    r_co_item = 'items_contenido=f\"\"\"([\s\S]*?)\"\"\"'
    co_item = re.findall(r_co_item, html_content, re.DOTALL)
    #2_cogemos el texto, buscamos las variables en texto y las convertimos en su valor. globals(), locals() para decirle si son variables globales o locales, en este caso son locales 
    resultado = eval(f"f'''{co_item[0]}'''", globals(), locals())   
    #3_ahora ya tenemos el mxl correcto para escribirlo
    items_contenido=f""" {resultado} """     
        
    try:
        # Leer el contenido actual del archivo
        with open(direccion, 'r', encoding='utf-8') as archivo:
            contenido_actual = archivo.read()
    except FileNotFoundError:
        #xbmcgui.Dialog().ok("Error de Archivo", "No se encontró el archivo en la ruta especificada.")
        return
    except IOError as e:
        #xbmcgui.Dialog().ok("Error de Archivo", f"No se pudo leer el archivo: {e}")
        return

    pos_inicio_items = contenido_actual.find("<items>")
    pos_fin_items = contenido_actual.find("</items>")
    
    if pos_inicio_items != -1 and pos_fin_items != -1:
        # Crear el nuevo contenido reemplazando lo que está entre <items> y </items>
        contenido_modificado = (contenido_actual[:pos_inicio_items + len("<items>")] + 
                                "\n" + items_contenido + "\n" + 
                                contenido_actual[pos_fin_items:])
        
        try:
            # Escribir el contenido modificado de vuelta al archivo
            with open(direccion, 'w', encoding='utf-8') as archivo:
                archivo.write(contenido_modificado)
            #xbmcgui.Dialog().ok("Éxito", "El archivo se actualizó correctamente.")
        except IOError as e:
            #xbmcgui.Dialog().ok("Error de Archivo", f"No se pudo escribir en el archivo: {e}")
            return
    else:
        xbmc.log("Error", xbmc.LOGINFO)
        xbmcgui.Dialog().ok("Error de XML", "No se encontró la etiqueta <items> en el archivo.") 
        return

    #xbmcgui.Dialog().ok("Proceso Completado", f"El archivo ha sido actualizado: {direccion}")
    
    return direccion