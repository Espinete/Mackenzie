import requests
import re
import xbmcvfs
import xbmc
import xbmcgui
import sys
import html
from concurrent.futures import ThreadPoolExecutor, as_completed
def tex_url(url):
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
    response = requests.get(url, headers=headers)
    response.raise_for_status()  # Lanza una excepción para errores HTTP
    response.encoding = 'utf-8'
    return response.text
    
def formulatv(url):    
    html_content = tex_url(url)
    matches = re.search(rf'{regex_1}', html_content)
    if not matches:
        url = url + 'ayer/'
        html_content = tex_url(url)        
        matches = re.search(rf'{regex_1}', html_content) 
        if not matches:
            matches = re.search(rf'{regex_4}', html_content)
            if not matches:#xbmcgui.Dialog().ok("Error", f"No se encontró información en {url} ni en url segunda")
                return "", "", "", "", ""  # Manejar el error devolviendo None
    r_matches = re.search(rf'{regex_2}', f'{matches.group(1)}')   
    foto_matches = re.search(rf'{regex_3}', f'{matches.group(1)}')
    if foto_matches:
        foto_matches = f'{foto_matches.group(1)}'
    else:
        foto_matches = "https://upload.wikimedia.org/wikipedia/commons/d/d9/Movistar%2B_Logo.png"    
    ini = r_matches.group(1)
    nombre = r_matches.group(2)
    foto = foto_matches
    fin = matches.group(2)
    nombre2 = matches.group(3)    
    nombre  = re.sub(r'<.*?>', '', nombre).strip()
    nombre2  = re.sub(r'<.*?>', '', nombre2).strip()
    
    return ini, nombre, foto, fin, nombre2
#xbmc.log(f"URL FINAL ES :   + {matches.group(3)}", xbmc.LOGINFO)
    #xbmcgui.Dialog().ok("formulatv()", f"{matches.group(3)}")
    #sys.exit()    
def tele():
    global regex_1, regex_2, regex_3, regex_4
    
    TRANSLATEPATH = xbmcvfs.translatePath
    url_local = 'special://home/addons/plugin.video.play/Tvdirec.html'
    direccion = TRANSLATEPATH(url_local)    
    url_regex = 'https://dl.dropbox.com/scl/fi/vib1ot3odpdb17nskov0k/CanalesdeMplus.html?rlkey=jcy5azsawgjokqfo4ioaj1nw3&st=14zjnpji&dl=0'
    html_content = tex_url(url_regex)
    variables = r"regex='(.*?)'"
    b_urls = r"url='(.*?)'"
    match_variables = re.findall(variables, html_content, re.DOTALL)
    regex_1, regex_2, regex_3, regex_4 = match_variables
    urls = re.findall(b_urls, html_content, re.DOTALL)    
    
    # Llamadas a la función para diferentes URLs    
    ### = formulatv(urls[1])
    ###hora_inicio_Mcomedia, programa_Mcomedia, foto_comedia, hora_fin_Mcomedia, programa2_Mcomedia = formulatv(urls[3])    
    ###hora_inicio_Mespa, programa_Mespa, foto_Mespa, hora_fin_Mespa, programa2_Mespa = formulatv(urls[5])
    results = {}

    # Usamos ThreadPoolExecutor para hacer las llamadas concurrentes
    with ThreadPoolExecutor(max_workers=5) as executor:
        future_to_url = {executor.submit(formulatv, urls[i]): i for i in range(1, len(urls), 2)}

        for future in as_completed(future_to_url):
            url_index = future_to_url[future]  # Obtener el índice original de la URL
            try:
                results[url_index] = future.result()  # Guardar el resultado con su índice original
            except Exception as exc:
                xbmcgui.Dialog().ok("Error al guardar", f"Error en la URL {urls[url_index]}: {exc}")

    # Ordenar los resultados según el índice original de las URLs
    ordered_results = [results[i] for i in sorted(results.keys())]

    # Asignar los resultados a variables específicas si hay suficientes
    if len(ordered_results) >= 1:  # Asegúrate de que haya suficientes resultados
        (hora_inicio_Maccion, programa_Maccion, foto_accion, hora_fin_Maccion, programa2_Maccion), \
        (hora_inicio_Mcomedia, programa_Mcomedia, foto_comedia, hora_fin_Mcomedia, programa2_Mcomedia), \
        (hora_inicio_Mespa, programa_Mespa, foto_Mespa, hora_fin_Mespa, programa2_Mespa), \
        (hora_inicio_Mestre, programa_Mestre, foto_Mestre, hora_fin_Mestre, programa2_Mestre), \
        (hora_inicio_Mdrama, programa_Mdrama, foto_Mdrama, hora_fin_Mdrama, programa2_Mdrama) = ordered_results
        
    #1_Capturamos todo el contenido en texto    
    r_co_item = 'items_contenido=f\"\"\"([\s\S]*?)\"\"\"'
    co_item = re.search(r_co_item, html_content, re.DOTALL)
    #2_cogemos el texto, buscamos las variables en texto y las convertimos en su valor. globals(), locals() para decirle si son variables globales o locales, en este caso son locales 
    resultado = eval(f"f'''{co_item.group(1)}'''")   
    #3_ahora ya tenemos el mxl correcto para escribirlo
    items_contenido=f""" {resultado} """     
        
    try:
        # Leer el contenido actual del archivo
        with open(direccion, 'r', encoding='utf-8') as archivo:
            contenido_actual = archivo.read()
    except FileNotFoundError:
        #xbmcgui.Dialog().ok("Error de Archivo", "No se encontró el archivo en la ruta especificada.")
        return
    except IOError as e:
        #xbmcgui.Dialog().ok("Error de Archivo", f"No se pudo leer el archivo: {e}")
        return

    pos_inicio_items = contenido_actual.find("<items>")
    pos_fin_items = contenido_actual.find("</items>")
    
    if pos_inicio_items != -1 and pos_fin_items != -1:
        # Crear el nuevo contenido reemplazando lo que está entre <items> y </items>
        contenido_modificado = (contenido_actual[:pos_inicio_items + len("<items>")] + 
                                "\n" + items_contenido + "\n" + 
                                contenido_actual[pos_fin_items:])
        
        try:
            # Escribir el contenido modificado de vuelta al archivo
            with open(direccion, 'w', encoding='utf-8') as archivo:
                archivo.write(contenido_modificado)
            #xbmcgui.Dialog().ok("Éxito", "El archivo se actualizó correctamente.")
        except IOError as e:
            #xbmcgui.Dialog().ok("Error de Archivo", f"No se pudo escribir en el archivo: {e}")
            return
    else:
        xbmc.log("Error", xbmc.LOGINFO)
        xbmcgui.Dialog().ok("Error de XML", "No se encontró la etiqueta <items> en el archivo.") 
        return

    #xbmcgui.Dialog().ok("Proceso Completado", f"El archivo ha sido actualizado: {direccion}")
    
    return direccion