# -*- coding: utf-8 -*-

import random
import re
import time
import urllib
from urllib.parse import urlparse, urlencode
from urllib.request import urlopen, Request, build_opener, HTTPCookieProcessor
from urllib.error import URLError
import http.cookiejar as cookielib
from base64 import b64encode
import xbmc
import xbmcgui
import xbmcaddon
import os

__scriptID__ = 'plugin.video.play'
__addon__ = xbmcaddon.Addon(__scriptID__)

class cInputWindow(xbmcgui.WindowDialog):
    def __init__(self, *args, **kwargs):
        bg_image = os.path.join(__addon__.getAddonInfo('path'), 'Images/', 'background.png')
        check_image = os.path.join(__addon__.getAddonInfo('path'), 'Images/', 'trans_checked.png')
        uncheck_image = os.path.join(__addon__.getAddonInfo('path'), 'Images/', 'trans_unchecked1.png')
        self.ctrlBackgound = xbmcgui.ControlImage(0, 0, 1280, 720, bg_image)
        self.cancelled = False
        self.addControl(self.ctrlBackgound)
        self.msg = kwargs.get('msg') + '\nNormally there are 3-4 selections and 2 rounds of pictures'
        self.round = kwargs.get('round')
        self.strActionInfo = xbmcgui.ControlLabel(335, 120, 700, 300, self.msg, 'font13', '0xFFFF00FF')
        self.addControl(self.strActionInfo)
        self.strActionInfo = xbmcgui.ControlLabel(335, 20, 724, 400, 'Captcha round %s' % (str(self.round)), 'font40', '0xFFFF00FF')
        self.addControl(self.strActionInfo)
        self.cptloc = kwargs.get('captcha')
        imgw = 400
        imgh = 300
        imgX = 335
        imgY = 200
        pw = imgw / 3
        ph = imgh / 3
        self.img = xbmcgui.ControlImage(imgX, imgY, imgw, imgh, self.cptloc)
        self.addControl(self.img)
        self.chk = [0] * 9
        self.chkbutton = [0] * 9
        self.chkstate = [False] * 9
        for obj in self.chk:
            self.addControl(obj)
            obj.setVisible(False)
        for obj in self.chkbutton:
            self.addControl(obj)
        self.cancelbutton = xbmcgui.ControlButton(imgX + (imgw / 2) - 110, imgY + imgh + 10, 100, 40, 'Cancel', alignment=2)
        self.okbutton = xbmcgui.ControlButton(imgX + (imgw / 2) + 10, imgY + imgh + 10, 100, 40, 'OK', alignment=2)
        self.addControl(self.okbutton)
        self.addControl(self.cancelbutton)
        self.chkbutton[6].controlDown(self.cancelbutton)
        self.chkbutton[6].controlUp(self.chkbutton[3])
        # continue defining control navigation rules...
        # ...
        self.setFocus(self.okbutton)
        # continue setting focus navigation rules...
        # ...

    def get(self):
        self.doModal()
        self.close()
        if not self.cancelled:
            retval = ""
            for objn in range(9):
                if self.chkstate[objn]:
                    retval += ("" if retval == "" else ",") + str(objn)
            return retval
        else:
            return ""

    def anythingChecked(self):
        for obj in self.chkstate:
            if obj:
                return True
        return False

    def onControl(self, control):
        if control == self.okbutton:
            if self.anythingChecked():
                self.close()
        elif control == self.cancelbutton:
            self.cancelled = True
            self.close()
        try:
            if 'xbmcgui.ControlButton' in repr(type(control)):
                index = control.getLabel()
                if index.isnumeric():
                    self.chkstate[int(index) - 1] = not self.chkstate[int(index) - 1]
                    self.chk[int(index) - 1].setVisible(self.chkstate[int(index) - 1])

        except:
            pass

    def onAction(self, action):
        if action == 10:
            self.cancelled = True
            self.close()


        
      
def getUrl(url, cookieJar=None, post=None, timeout=20, headers=None, noredir=False):
    xbmc.log(str(url), xbmc.LOGINFO) 
    xbmcgui.Dialog().ok("Estoy dentro de geturl", str(url))
    
    cookie_handler = urllib.request.HTTPCookieProcessor(cookieJar)

    if noredir:
        opener = urllib.request.build_opener(NoRedirection, cookie_handler, urllib.request.HTTPBasicAuthHandler(), urllib.request.HTTPHandler())
    else:
        opener = urllib.request.build_opener(cookie_handler, urllib.request.HTTPBasicAuthHandler(), urllib.request.HTTPHandler())

    req = urllib.request.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, como Gecko) Chrome/83.0.4103.97 Safari/537.36 CrKey/1.44.191160')
    
    if headers:
        for h, hv in headers:
            req.add_header(h, hv)

    if post:
        post = urlencode(post).encode('utf-8')
    try: 
        response = opener.open(req, data=post, timeout=timeout)        
        link = response.read().decode('utf-8')
        xbmc.log(str(link), xbmc.LOGINFO) 
        xbmcgui.Dialog().ok("todo correcto", str(link))
    except urllib.error.URLError as e:
        xbmc.log("Error al recibir al srvidor", xbmc.LOGINFO) 
        xbmcgui.Dialog().ok("Error al recibir la url", "Error al recibir al srvidor")
    finally:
        if response:
            response.close()
    
    return link
class UnCaptchaReCaptcha:
    def processCaptcha(self, key, lang):
        
        headers = [
            ("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, como Gecko) Chrome/83.0.4103.97 Safari/537.36 CrKey/1.44.191160"),
            ("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"),
            ("Referer", "https://www.google.com/recaptcha/api2/demo"),
            ("Accept-Language", lang)
        ]

        html = getUrl("http://www.google.com/recaptcha/api/fallback?k=" + key, headers=headers)
        
        xbmc.log(" DE AQUI PARA ABAJO" + str(html), xbmc.LOGINFO) 
        xbmcgui.Dialog().ok("estoy html", str(html))
        #https://www.google.com/recaptcha/api2/reload?k=6Le-wvkSAAAAAPBMRTvw0Q4Muexq9bi0DJwx_mJ-
        token = ""
        round = 0
        while True:
            payload = re.findall("\"(/recaptcha/api2/payload[^\"]+)", html)
            round += 1
            message = re.findall("<label .*?class=\"fbc-imageselect-message-text\">(.*?)</label>", html)
            if len(message) == 0:
                message = re.findall("<div .*?class=\"fbc-imageselect-message-error\">(.*?)</div>", html)
            if len(message) == 0:
                token = re.findall("\"this\\.select\\(\\)\">(.*?)</textarea>", html)[0]
                if not token == "":
                    line1 = "Captcha Sucessfull"
                    xbmc.executebuiltin('Notification(%s, %s, %d, %s)' % ('Play', line1, 3000, None))
                else:
                    line1 = "Captcha failed"
                    xbmc.executebuiltin('Notification(%s, %s, %d, %s)' % ('Play', line1, 3000, None))
                break
            else:
                message = message[0]
                payload = payload[0]

            imgurl = re.findall("name=\"c\"\\s+value=\\s*\"([^\"]+)", html)[0]

            headers = [
                ("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, como Gecko) Chrome/83.0.4103.97 Safari/537.36 CrKey/1.44.191160"),
                ("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"),
                ("Referer", "http://www.google.com/recaptcha/api/fallback?k=" + key),
                ("Accept-Language", lang)
            ]

            cval = re.findall('name="c" value="(.*?)"', html)[0]
            captcha_imgurl = "https://www.google.com" + payload.replace('&amp;', '&')

            message = message.replace('<strong>', '')
            message = message.replace('</strong>', '')

            oSolver = cInputWindow(captcha=captcha_imgurl, msg=message, round=round)
            captcha_response = oSolver.get()

            if captcha_response == "":
                break
            responses = ""
            for rr in captcha_response.split(','):
                responses += "&response=" + rr

            html = getUrl("http://www.google.com/recaptcha/api/fallback?k=" + key,
                          post=urlencode({'c': cval}) + responses, headers=headers)

        return token






def performCaptcha(sitename, cj, returnpage=True, captcharegex='data-sitekey="(.*?)"', lang="en", headers=None):
    sitepage = getUrl(sitename, cookieJar=cj, headers=headers)
    
    sitekey = re.findall(captcharegex, sitepage)
    #xbmc.log(str(sitekey), xbmc.LOGINFO) 
    #xbmcgui.Dialog().ok("Estoy dentro de performCaptcha", str(sitekey))
    token = ""
    if len(sitekey) >= 1:
        c = UnCaptchaReCaptcha()
        token = c.processCaptcha(sitekey[0], lang)
        #xbmc.log(str(token), xbmc.LOGINFO) 
        #xbmcgui.Dialog().ok("Estoy dentro de performCaptcha", str(token))
        if returnpage:
            if headers is None:
                headers = [
                    ("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, como Gecko) Chrome/83.0.4103.97 Safari/537.36 CrKey/1.44.191160"), ("Referer", sitename)
                ]
            else:
                headers += [("Referer", sitename)]
            sitepage = getUrl(sitename, cookieJar=cj, post=urlencode({"g-recaptcha-response": token}), headers=headers)

    if returnpage:
        return sitepage
    else:
        return token


#cookieJar = cookielib.LWPCookieJar()
#performCaptcha("http://www.livetv.tn/",cookieJar);


