import base64
import xbmcgui
import xbmc
import xbmcplugin
import xbmcaddon
from bs4 import BeautifulSoup
import requests
import re
import sys
import time
import os

def cajon(page_data, url):
    
        dialog = xbmcgui.Dialog()
        respuesta = dialog.select('¿ Qué eliges ver ?', ['                                <<<  [COLOR green][B]Ver pelicula[/B][/COLOR]  >>>', '                                    <<  [COLOR green][B]Ver trailer[/B][/COLOR]  >>'])
        if respuesta == -1:
            sys.exit()
            #xbmcgui.Dialog().textviewer("estoy click en cancelar", str(respuesta))
            #xbmc.executebuiltin("Action(Back)")           
        elif respuesta == 0: 
            if url.startswith('plugin://plugin.video.palantir3'):
                addon_id = 'plugin.video.palantir3'               
                addon = xbmcaddon.Addon(addon_id)    
                xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, xbmcgui.ListItem(path=url))
            elif url.startswith('Estreno:'):               
                 # Ruta local al icono en la misma carpeta que tu script
                addon_icon_path = os.path.join(xbmc.translatePath('special://home/addons/plugin.video.play'), 'icon.png')
                # Convierte la ruta local a una ruta special://
                icon_path = xbmc.translatePath(addon_icon_path)

                # Muestra la notificación con la ruta especial
                xbmcgui.Dialog().notification('[COLOR green]                  No seas impaciente[/COLOR]', f'[COLOR pink][B]   {url}[/COLOR][/B]', icon=icon_path, time=4000)                
                sys.exit()
            else:
                #xbmcgui.Dialog().textviewer("cuando no es pal", url)
                return url
        elif respuesta == 1:
            
                if page_data.startswith('plugin://plugin.video.imdb.trailers'):
                    addon_id = 'plugin.video.imdb.trailers'
                    addon = xbmcaddon.Addon(addon_id)
                    list_item = xbmcgui.ListItem(path=page_data)
                    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=list_item)
                    
                    
                else:
                    #xbmcgui.Dialog().textviewer("estoy dentro de youtube", page_data)
                    addon_id = 'plugin.video.duffyou'
                    addon = xbmcaddon.Addon(addon_id)
                    list_item = xbmcgui.ListItem(path=page_data)
                    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=list_item)
                    
        sys.exit()#con esto se para dentro de la funcion y no vuelve al xml
                    