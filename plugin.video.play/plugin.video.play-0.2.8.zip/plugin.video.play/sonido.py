import xbmc
import xbmcgui
import time

def topuria (url):
     mp3 = "special://home/addons/plugin.video.play/resources/lib/topuria.mp3"
     xbmc.Player().play(mp3)
     time.sleep(8)
     url = "https://dl.dropbox.com/s/7cvtsxlyfcog69t/topuria.html"
     return url