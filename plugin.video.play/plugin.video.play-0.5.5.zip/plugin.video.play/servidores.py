import xbmcgui
import xbmc
import xbmcplugin
import xbmcaddon
from bs4 import BeautifulSoup
import requests
import re
import sys
import time
import six
 
    
def resolver (url, regex):
    #funciona para GAMOVIDEO y SENDVID
    #xbmc.log("URL es...: " + url, xbmc.LOGINFO)
    #xbmcgui.Dialog().ok("Estoy dentro de m3u", url) 
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
    response = requests.get(url, headers=headers)
    html_content = response.text
    if "gamovideo" in url:
        match = re.search(regex, html_content)
        url_final = match.group(1)        
    else: 
        regex = '(?s)og:video. content="([^"]+)'
        #xbmcgui.Dialog().ok("Estoy dentro de sendvid", html_content)
        match = re.search(regex, html_content)
        url_final = match.group(1)     
    return url_final    
    
def resolver_Streamwish(url, regex):
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
    response = requests.get(url, headers=headers)
    html_content = response.text
    match = re.search(regex, html_content)
    url_final = match.group(1)
    return url_final

    
def resolver_Streamvid (url, regex1, regex2):     
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
    response = requests.get(url, headers=headers)
    html_content = response.text
    
    match = re.search(f"{regex1}.*?{regex2}", html_content)
    if match:
        cacho1 = match.group(1)
        cacho2 = match.group(2)
        url_final = f"https://{cacho1}.flyeyes.pics/hls/,{cacho2},.urlset/master.m3u8" 
    else:    
        regex1 = "(?s)\|media\|\|([^\|]+)"
        match = re.search(f"{regex1}.*?{regex2}", html_content)
        if match:
            cacho1 = match.group(1)
            cacho2 = match.group(2)
            url_final = f"https://{cacho1}.streamvid.media/hls/,{cacho2},.urlset/master.m3u8"
        else:
            regex1 = "(?s)\|false\|([^\|]+)"
            match = re.search(f"{regex1}.*?{regex2}", html_content)
            cacho1 = match.group(1)
            cacho2 = match.group(2)
            url_final = f"https://{cacho1}.streamvid.net/hls/,{cacho2},.urlset/master.m3u8"
        
    
    #xbmc.log("URL es...: " + url_final, xbmc.LOGINFO)
    #xbmcgui.Dialog().ok("Estoy dentro de m3u", url_final)                  
    return url_final  
    
def resolver_Vtube (url, regex1, regex2): 
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
    response = requests.get(url, headers=headers)
    html_content = response.text
    #xbmc.log("URL es...: " + html_content, xbmc.LOGINFO)
    #xbmcgui.Dialog().ok("Estoy dentro de m3u", html_content)
    
    match = re.search(f"{regex1}.*?{regex2}", html_content)
    cacho2 = match.group(1)    
    cacho1 = match.group(2)    
    url_final = f"https://{cacho1}.vtube.network/hls/,{cacho2},.urlset/master.m3u8"  
    #xbmcgui.Dialog().ok("Estoy dentro de m3u", url_final)
    return url_final
    
