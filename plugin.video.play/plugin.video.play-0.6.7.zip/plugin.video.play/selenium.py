import xbmcgui
import urllib
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities

def vidmoly(url):
    
    xbmcgui.Dialog().ok("confirmacion", url)
    user_agent = "Mozilla/5.0 (iPad; CPU OS 9_1 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13B143 Safari/601.1"
    
    #xbmc.log("correcto", xbmc.LOGINFO)
    #xbmcgui.Dialog().ok("confirmacion", "correcta")