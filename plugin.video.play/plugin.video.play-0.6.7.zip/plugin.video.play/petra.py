import base64
import xbmcgui
import xbmc
import xbmcplugin
import xbmcaddon
from bs4 import BeautifulSoup
import requests
import re
import sys
import time
import os
import xbmcvfs
import sqlite3
import urllib
def texto_url(url):
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
    response = requests.get(url, headers=headers)
    html_content = response.text
    return html_content
    
def url_con_cabeza(url, regex):    
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
    response = requests.get(url, headers=headers)
    html_content = response.text  
    
    match = re.search(regex, html_content)
    url_final = match.group(1)
    
    url_final_with_headers = f'''{url_final}|Mozilla/5.0(WindowsNT10.0;Win64;x64)AppleWebKit/537.36(KHTML,likeGecko)Chrome/98.0.4758.102Safari/537.36'''
    #xbmc.log(url_final_with_headers, xbmc.LOGINFO) 
    #xbmcgui.Dialog().ok("Estoy dentro de url_con_cabeza", html_content)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=xbmcgui.ListItem(path=url_final_with_headers))
    sys.exit()
    
def resolver_Vtube(url, regex1, regex2): 
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
    response = requests.get(url, headers=headers)
    html_content = response.text
        
    match = re.search(f"{regex1}.*?{regex2}", html_content)
    cacho2 = match.group(1)    
    cacho1 = match.group(2)    
    url_final = f"https://{cacho1}.vtube.network/hls/{cacho2}.urlset/master.m3u8"  
    #xbmc.log(url_final, xbmc.LOGINFO) 
    url_final_with_headers = f'''{url_final}|Mozilla/5.0(WindowsNT10.0;Win64;x64)AppleWebKit/537.36(KHTML,likeGecko)Chrome/98.0.4758.102Safari/537.36'''
    
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=xbmcgui.ListItem(path=url_final_with_headers))
    sys.exit()
    
def cajon(trailer, url, saltar):
    #xbmcgui.Dialog().ok("dentro de petra.cajon", str(url))
    
    salta_cajon = int(saltar)
    
    #Cuando salta_cajon es 1 y respuesta = 0 va directamente a darte la pelicula seccion hecha para cine kinki
    if salta_cajon == 1:
        respuesta = 0
        if any(substring in trailer for substring in ["duffyou", "moestv", "imdb", "vidhidepre"]):            
            respuesta = 1
            #xbmcgui.Dialog().ok("paso 1/4", "respuesta = 1")
    # Determinar la función de traducción de ruta adecuada según la versión de Kodi
    kodi_version = xbmc.getInfoLabel('System.BuildVersion')
    if kodi_version.startswith('19'):
        from xbmc import translatePath as variacion_translatePath
        db_name = "MyVideos119.db"
    elif int(kodi_version.split('.')[0]) >= 20:
        from xbmcvfs import translatePath as variacion_translatePath
        db_name = "MyVideos121.db"
    else:
        raise RuntimeError("Versión de Kodi no compatible")
    
    
    ruta_especial_kodi = xbmcvfs.translatePath("special://database/").encode("utf-8").decode("utf-8")        
    nombre_db = db_name
    ruta_completa_db = os.path.join(ruta_especial_kodi, nombre_db)
    #xbmcgui.Dialog().textviewer("ruta", str(ruta_completa_db))
    # Conecta con la base de datos SQLite
    conexion = sqlite3.connect(ruta_completa_db)
    cursor = conexion.cursor()
    #xbmc.log(str(cursor), xbmc.LOGINFO)
    #xbmcgui.Dialog().textviewer("ruta", str(cursor))
    try:
        # Consulta para obtener todos los datos de la columna strFilename de la tabla files
        cursor.execute("SELECT idFile, strFilename FROM files;")
        resultados = cursor.fetchall()
        
        # Variable para verificar si se encontraron datos
        datos_encontrados = False

        # Imprime los resultados en el log de Kodi
        for resultado in resultados:
            decoded_str_filename = urllib.parse.unquote(resultado[1])  # Decodificar la cadena
            #xbmc.log(f"ID: {resultado[0]}, strFilename: {decoded_str_filename}", xbmc.LOGINFO)
            
            
            if url in decoded_str_filename:
                # Se encontró la URL en el strFilename. Ahora, consultamos la tabla bookmark
                cursor.execute("SELECT idBookmark FROM bookmark WHERE idFile = ?;", (resultado[0],))
                bookmark_resultado = cursor.fetchone()

                if bookmark_resultado:
                    #xbmcgui.Dialog().ok("BINGO!!!!", f"Se encontró la URL en el strFilename. ID: {resultado[0]}\nID Bookmark: {bookmark_resultado[0]}")
                    salta_cajon = 1
                    respuesta = 0
                    if any(substring in trailer for substring in ["duffyou", "moestv", "imdb", "vidhidepre"]):
                        respuesta = 1
                        #xbmcgui.Dialog().ok("paso 2/4", "seguimos insistiendo en respuesta = 1")
                    conexion.close()
                #else:
                    #xbmcgui.Dialog().ok("BINGO!!!!", f"Se encontró la URL en el strFilename. ID: {resultado[0]}\nNo hay Bookmark asociado.")

                #datos_encontrados = True

        # Muestra el mensaje adecuado en el diálogo de Kodi
        #if not datos_encontrados:
            #xbmcgui.Dialog().ok("Datos encontrados.", "NINGUNO")

    except sqlite3.Error as e:
        xbmc.log(f"Error al consultar la base de datos: {e}", xbmc.LOGERROR)

    finally:
        # Cierra la conexión con la base de datos
        if conexion:
            conexion.close()
    #xbmcgui.Dialog().textviewer("ruta", str(cursor))
    

    #xbmcgui.Dialog().ok("ruta", str(salta_cajon))
    if salta_cajon == 0:
        if url.startswith('Estreno:'):
            dialog = xbmcgui.Dialog()
            respuesta = dialog.select('Próximamente......', [f'                                                        [COLOR pink][B]   {url}[/COLOR][/B]  ', '                                    <<  [COLOR green][B]Ver trailer[/B][/COLOR]  >>'])
        else:            
            dialog = xbmcgui.Dialog()
            respuesta = dialog.select('¿ Qué eliges ver ?                                                            ', ['                                <<<  [COLOR green][B]Ver película[/B][/COLOR]  >>>', '                                    <<  [COLOR green][B]Ver tráiler[/B][/COLOR]  >>'])
    
    if respuesta == -1:
        sys.exit()
        #xbmcgui.Dialog().textviewer("estoy click en cancelar", str(respuesta))
        #xbmc.executebuiltin("Action(Back)")           
    elif respuesta == 0: 
        if "https://vidhidepre.com/" in url:
            try:
                import servidores
                resolved_url = servidores.resolver_Streamwish(url, '(?s): \[{file:"([^"]+)')            
                url = resolved_url        
                return url
                #xbmc.log(url, xbmc.LOGINFO) 
                #xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=xbmcgui.ListItem(path=url))#con la url resuelta se la mandamos a kodi para que el reproductor la reproduzca
                
            except:
                url_descargas = url.replace("/file/", "/download/")      
                html_content = texto_url(url_descargas)
                
                if '.mkv' in html_content:
                    prefijo = "_n" 
                    nueva_url_descargas = url_descargas + prefijo
                    html_content = texto_url(nueva_url_descargas)
                    
                    if 'Downloads disabled' in html_content:
                        xbmcgui.Dialog().ok("Aviso de codificación", "Pendiente de codificación, cuando termine el proceso podrás disfrutar del video, disculpe las molestias.")
                        sys.exit()
                
                html_content = texto_url(url)
                if "Please allow a few hours for the file to be" in html_content:       
                    xbmcgui.Dialog().ok("Servidor en mantenimiento", "Espere unas horas para que el archivo se transfiera a un servidor de mayor rendimiento. Gracias por su paciencia.")
                    sys.exit()
        elif url.startswith('plugin://plugin.video.palantir3'):
            ###addon_id = 'plugin.video.palantir3'               
            ###addon = xbmcaddon.Addon(addon_id)    
            ###xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, xbmcgui.ListItem(path=url))
            #xbmcgui.Dialog().ok("estoy en petra", str(respuesta))
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=xbmcgui.ListItem(path=url))
            #xbmcgui.Dialog().textviewer("estoy click en cancelar", str(respuesta))
            sys.exit()
        elif url.startswith('Estreno:'):               
             # Ruta local al icono en la misma carpeta que tu script
            addon_icon_path = os.path.join(variacion_translatePath('special://home/addons/plugin.video.play'), 'icon.png')
            # Convierte la ruta local a una ruta special://
            icon_path = variacion_translatePath(addon_icon_path)

            # Muestra la notificación con la ruta especial
            xbmcgui.Dialog().notification('[COLOR green]                  No seas impaciente[/COLOR]', f'[COLOR pink][B]   {url}[/COLOR][/B]', icon=icon_path, time=4000)                
            sys.exit()
        elif "sendvid" in url:                 
            regex = '(?s)og:video. content="([^"]+)'
            url_con_cabeza(url, regex)            
        elif "asnwish" in url: 
            #xbmcgui.Dialog().ok("Estoy dentro de vidhidepre", "a ver ")
            regex = '(?s): \[{file:"([^"]+)'
            url_con_cabeza(url, regex) 
        elif "videzz.net" in url or "vidoza.net" in url:
            regex = 'src: "([^"]+)'
            url_con_cabeza(url, regex)
        elif "gamovideo" in url:
            regex = '(?s)sources:.*?file: "([^"]+)'
            url_con_cabeza(url, regex)            
            #xbmc.log(str(url_final_with_headers), xbmc.LOGINFO)
            #xbmcgui.Dialog().ok("Estoy dentro de gamovideo", "a ver ")
        elif "vtbe" in url or "vtube" in url: 
            regex1 = '(?s)\|urlset\|([^\|]+)'
            regex2 = '(?s)hls\|([^\|]+)'
            resolver_Vtube(url, regex1, regex2)
        else:
            #xbmcgui.Dialog().textviewer("cuando no es pal", url)
            
            return url
    elif respuesta == 1:
        
        if "imdb" in trailer:
            #xbmcgui.Dialog().ok("paso 3/4", "estoy dentro de imbd")
            #xbmc.log(trailer, xbmc.LOGINFO)
            trailer = trailer.replace("&amp;", "&")
            #xbmc.log(trailer, xbmc.LOGINFO)
            #xbmcgui.Dialog().ok("paso 4/4", "dentro de plugin://plugin.video.imdb.trailers")
            #addon_id = 'plugin.video.imdb.trailers'
            #addon = xbmcaddon.Addon(addon_id)
            list_item = xbmcgui.ListItem(path=trailer)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=list_item)
            sys.exit()
        elif trailer.startswith('plugin://plugin.video.moestv'):
            #xbmc.log(trailer, xbmc.LOGINFO)
            #xbmcgui.Dialog().ok("paso 4/4", "dentro de plugin://plugin.video.moestv")
            ### SE HIZO ASI POR QUE DE LA OTRA MANERA SERIA IMPOSIBLE
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=xbmcgui.ListItem(path=trailer))                        
            sys.exit()        
        elif trailer.startswith('plugin://plugin.video.duffyou'):
            #xbmcgui.Dialog().textviewer("estoy dentro de youtube", trailer)
            addon_id = 'plugin.video.duffyou'
            addon = xbmcaddon.Addon(addon_id)
            list_item = xbmcgui.ListItem(path=trailer)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=list_item)
            sys.exit()
        else:
            #xbmcgui.Dialog().textviewer("trailer diamon", trailer)
            import resolveurl
            resolved_url = resolveurl.resolve(trailer)            
            url = resolved_url            
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=xbmcgui.ListItem(path=url))#con la url resuelta se la mandamos a kodi para que el reproductor la reproduzca
                
    sys.exit()#con esto se para dentro de la funcion y no vuelve al xml
                    