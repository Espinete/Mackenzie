import os
import sys
import xbmc

# Determinar la función de traducción de ruta adecuada según la versión de Kodi
kodi_version = xbmc.getInfoLabel('System.BuildVersion')
if kodi_version.startswith('19'):
    from xbmc import translatePath as variacion_translatePath
elif int(kodi_version.split('.')[0]) >= 20:
    from xbmcvfs import translatePath as variacion_translatePath
else:
    raise RuntimeError("Versión de Kodi no compatible")
# Ruta completa a la carpeta en addon_data
addon_data_folder = variacion_translatePath('special://profile/addon_data/')
skin_xonfluence_folder = os.path.join(addon_data_folder, 'skin.xonfluence')
# Verificar si la carpeta skin.xonfluence existe en la primera ubicación
if os.path.exists(skin_xonfluence_folder):
    # La carpeta existe, sale del script
    #xbmcgui.Dialog().ok("Resultado", "La carpeta skin.xonfluence existe.")
    sys.exit()

import shutil
import xbmcgui



    
plugin_video_play_folder = os.path.join(addon_data_folder, 'plugin.video.play')
script_embuary_info_folder = os.path.join(addon_data_folder, 'script.embuary.info')

# Ruta completa al archivo sources.xml en la segunda ubicación
second_location_sources_xml = variacion_translatePath('special://home/addons/plugin.video.play/resources/lib/sources.xml')
# Ruta completa al archivo sources.xml en la carpeta userdata
userdata_sources_xml = variacion_translatePath('special://userdata/sources.xml')


second_location_advancedsettings_xml = variacion_translatePath('special://home/addons/plugin.video.play/resources/lib/advancedsettings.xml')
userdata_advancedsettings_xml = variacion_translatePath('special://userdata/advancedsettings.xml')
if os.path.exists(skin_xonfluence_folder):
    # La carpeta existe, muestra un cuadro de diálogo OK y sale del script
    #xbmcgui.Dialog().ok("Resultado", "La carpeta skin.xonfluence existe.")
    sys.exit()


else:
    # La carpeta no existe en la primera ubicación, verifica en la segunda ubicación
    second_location_skin_xonfluence = variacion_translatePath('special://home/addons/plugin.video.play/resources/lib/skin.xonfluence')
    second_location_plugin_video_play = variacion_translatePath('special://home/addons/plugin.video.play/resources/lib/plugin.video.play')
    second_location_script_embuary_info = variacion_translatePath('special://home/addons/plugin.video.play/resources/lib/script.embuary.info')
    second_location_script_module_resolveurl = variacion_translatePath('special://home/addons/plugin.video.play/resources/lib/script.module.resolveurl')
    if os.path.exists(second_location_skin_xonfluence):
        # La carpeta existe en la segunda ubicación, copia y pega en la primera ubicación
        shutil.copytree(second_location_skin_xonfluence, skin_xonfluence_folder)
        #xbmcgui.Dialog().ok("Resultado", "La carpeta skin.xonfluence copiada de la segunda ubicación a la primera.")
    else:
        # La carpeta no existe en ninguna de las ubicaciones, muestra un cuadro de diálogo OK
        xbmcgui.Dialog().ok("Resultado", "La carpeta skin.xonfluence no existe en ninguna de las ubicaciones.")
    if os.path.exists(second_location_plugin_video_play):
        # La carpeta existe en la segunda ubicación, copia y pega en la primera ubicación
        shutil.copytree(second_location_plugin_video_play, plugin_video_play_folder)
        #xbmcgui.Dialog().ok("Resultado", "La carpeta plugin.video.play copiada de la segunda ubicación a la primera.")
    else:
        # La carpeta no existe en ninguna de las ubicaciones, muestra un cuadro de diálogo OK
        xbmcgui.Dialog().ok("Resultado", "La carpeta plugin.video.play no existe en ninguna de las ubicaciones.")
    if os.path.exists(second_location_script_embuary_info):
        # La carpeta existe en la segunda ubicación, copia y pega en la primera ubicación
        shutil.copytree(second_location_script_embuary_info, script_embuary_info_folder)
        #xbmcgui.Dialog().ok("Resultado", "La carpeta plugin.video.play copiada de la segunda ubicación a la primera.")
    else:
        # La carpeta no existe en ninguna de las ubicaciones, muestra un cuadro de diálogo OK
        xbmcgui.Dialog().ok("Resultado", "La carpeta script_embuary_info no existe en ninguna de las ubicaciones.")
    if os.path.exists(second_location_sources_xml):
        shutil.copy2(second_location_sources_xml, userdata_sources_xml)
        #xbmcgui.Dialog().ok("Resultado", "El archivo sources.xml copiado a userdata.")
    else:
        xbmcgui.Dialog().ok("Resultado", "El archivo sources.xml no existe en la segunda ubicación.")
    if os.path.exists(second_location_advancedsettings_xml):
        shutil.copy2(second_location_advancedsettings_xml, userdata_advancedsettings_xml)
        #xbmcgui.Dialog().ok("Resultado", "El archivo advancedsettings.xml copiado a userdata.")
    else:
        xbmcgui.Dialog().ok("Resultado", "El archivo advancedsettings.xml no existe en la segunda ubicación.")


    
    
    






