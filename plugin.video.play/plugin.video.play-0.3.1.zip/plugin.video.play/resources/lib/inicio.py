import os
import sys
import xbmc
import shutil
import xbmcgui
from xbmcvfs import translatePath as TRANSLATEPATH

# Determinar la función de traducción de ruta adecuada según la versión de Kodi

# Ruta completa a la carpeta en addon_data
addon_data_folder = TRANSLATEPATH('special://profile/addon_data/')

# Verificar si la carpeta skin.xonfluence existe en la primera ubicación

skin_xonfluence_folder = os.path.join(addon_data_folder, 'skin.xonfluence')
plugin_video_play_folder = os.path.join(addon_data_folder, 'plugin.video.play')
script_embuary_info_folder = os.path.join(addon_data_folder, 'script.embuary.info')

# Ruta completa al archivo sources.xml en la segunda ubicación
second_location_sources_xml = TRANSLATEPATH('special://home/addons/plugin.video.play/resources/lib/sources.xml')
second_location_advancedsettings_xml = TRANSLATEPATH('special://home/addons/plugin.video.play/resources/lib/advancedsettings.xml')

# Ruta completa al archivo sources.xml en la carpeta userdata
userdata_sources_xml = TRANSLATEPATH('special://userdata/sources.xml')
userdata_advancedsettings_xml = TRANSLATEPATH('special://userdata/advancedsettings.xml')

# La carpeta no existe en la primera ubicación, verifica en la segunda ubicación
second_location_skin_xonfluence = TRANSLATEPATH('special://home/addons/plugin.video.play/resources/lib/skin.xonfluence')
second_location_plugin_video_play = TRANSLATEPATH('special://home/addons/plugin.video.play/resources/lib/plugin.video.play')
second_location_script_embuary_info = TRANSLATEPATH('special://home/addons/plugin.video.play/resources/lib/script.embuary.info')

if os.path.exists(second_location_skin_xonfluence):
    # La carpeta existe en la segunda ubicación, copia y pega en la primera ubicación
    shutil.copytree(second_location_skin_xonfluence, skin_xonfluence_folder)
    #xbmcgui.Dialog().ok("Resultado", "La carpeta skin.xonfluence copiada de la segunda ubicación a la primera.")
else:
    # La carpeta no existe en ninguna de las ubicaciones, muestra un cuadro de diálogo OK
    xbmcgui.Dialog().ok("Resultado", "La carpeta skin.xonfluence no existe en ninguna de las ubicaciones.")
if os.path.exists(second_location_plugin_video_play):
    # La carpeta existe en la segunda ubicación, copia y pega en la primera ubicación
    shutil.copytree(second_location_plugin_video_play, plugin_video_play_folder)
    #xbmcgui.Dialog().ok("Resultado", "La carpeta plugin.video.play copiada de la segunda ubicación a la primera.")
else:
    # La carpeta no existe en ninguna de las ubicaciones, muestra un cuadro de diálogo OK
    xbmcgui.Dialog().ok("Resultado", "La carpeta plugin.video.play no existe en ninguna de las ubicaciones.")
if os.path.exists(second_location_script_embuary_info):
    # La carpeta existe en la segunda ubicación, copia y pega en la primera ubicación
    shutil.copytree(second_location_script_embuary_info, script_embuary_info_folder)
    #xbmcgui.Dialog().ok("Resultado", "La carpeta plugin.video.play copiada de la segunda ubicación a la primera.")
else:
    # La carpeta no existe en ninguna de las ubicaciones, muestra un cuadro de diálogo OK
    xbmcgui.Dialog().ok("Resultado", "La carpeta script_embuary_info no existe en ninguna de las ubicaciones.")
if os.path.exists(second_location_sources_xml):
    shutil.copy2(second_location_sources_xml, userdata_sources_xml)
    #xbmcgui.Dialog().ok("Resultado", "El archivo sources.xml copiado a userdata.")
else:
    xbmcgui.Dialog().ok("Resultado", "El archivo sources.xml no existe en la segunda ubicación.")
if os.path.exists(second_location_advancedsettings_xml):
    shutil.copy2(second_location_advancedsettings_xml, userdata_advancedsettings_xml)
    #xbmcgui.Dialog().ok("Resultado", "El archivo advancedsettings.xml copiado a userdata.")
else:
    xbmcgui.Dialog().ok("Resultado", "El archivo advancedsettings.xml no existe en la segunda ubicación.")
    
xbmcgui.Dialog().ok("Resultado", "Acabo de copiar todo con exito")
xbmc.executebuiltin('Action(ParentDir)')



    
    
    






